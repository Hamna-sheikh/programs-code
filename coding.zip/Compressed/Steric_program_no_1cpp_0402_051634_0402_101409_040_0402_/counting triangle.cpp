//Write a program of counting in which j decrement ? 




#include<iostream>
using namespace std;

int main()
{
  int n=5;
for (int i=1;i<=n;i++)
{
for(int j=1;j<=n;j++)
{
   if(i<=j);
    cout<<"i";
    else
  cout<<" "
   }
   cout<<endl;
    }
   return 0; 
}
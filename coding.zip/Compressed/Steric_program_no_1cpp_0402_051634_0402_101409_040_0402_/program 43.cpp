
//579
//791113
//9111317 progrqm 43



#include<iostream>
using namespace std;

int main()
{
int i,j,t;

for(i=1;i<=5;i++)
{
t=i-1;
for(j=1;j<=i;j++)
{
   
  
  cout<<t+i<<"";
  t+=2;
   }
   cout<<endl;
    }
   return 0; 
}
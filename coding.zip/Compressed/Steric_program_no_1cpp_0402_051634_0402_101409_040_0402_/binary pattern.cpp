

//binary triangle pattten
#include <iostream>
using namespace std;

int main() {
    int n = 4, i = 1;
    do {
        int j = 1;
        do {
            cout << (i + j) % 2 << " ";
            j++;
        } while (j <= i);
        cout << endl;
        i++;
    } while (i <= n);
    return 0;
}
//Write a program of sterric half upper diamond  ? 




#include<iostream>
using namespace std;

int main()
{
  int n=5;
  int i,j;
for (int i=1;i<=n;i++)
{
for(int j=n;j>=1;j++)
{
   if(i>=j)
    cout<<"*";//space after '*'
  else
  
  cout<<"";
   }
   cout<<endl;
    }
   return 0; 
}
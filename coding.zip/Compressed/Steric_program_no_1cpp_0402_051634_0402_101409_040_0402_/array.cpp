#include <iostream>
using namespace std;

int main() {
    int n = 5;
    char pattern[5][5];

    // Fill array for diagonal stars
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j || i + j == n - 1)
                pattern[i][j] = '*';
            else
                pattern[i][j] = ' ';
        }
    }

    // Display the pattern
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << pattern[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
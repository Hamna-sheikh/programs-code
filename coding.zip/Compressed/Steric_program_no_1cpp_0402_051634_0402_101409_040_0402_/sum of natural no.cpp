#include <iostream>
using namespace std;

int main() {
    int sum = 0, i = 1;
    while (i <= 10) {
        sum += i;
        i++;
    }
    cout << "Sum: " << sum << endl;
    return 0;
}
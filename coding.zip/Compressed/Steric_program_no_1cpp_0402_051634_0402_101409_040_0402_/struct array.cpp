#include <iostream>
using namespace std;

struct Point {
    int x, y;
};

int main() {
    // Declare and initialize an array of 3 struct Point
    Point points[3] = {{1, 2}, {3, 4}, {5, 6}};

    // Display the points
    for (int i = 0; i < 3; i++) {
        cout << "Point " << i + 1 << ": (" << points[i].x << ", " << points[i].y << ")\n";
    }

    return 0;
}
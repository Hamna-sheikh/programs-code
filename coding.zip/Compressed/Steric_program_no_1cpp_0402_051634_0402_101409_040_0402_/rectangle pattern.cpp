#include <iostream>
using namespace std;

int main() {
    int rows, cols;
    cout << "Enter number of rows and columns: ";
    cin >> rows >> cols;

    for (int i = 0; i < rows; i++) {
        char ch = 'A' + i;
        for (int j = 0; j < cols; j++) {
            cout << ch << " ";
        }
        cout << endl;
    }

    return 0;
}
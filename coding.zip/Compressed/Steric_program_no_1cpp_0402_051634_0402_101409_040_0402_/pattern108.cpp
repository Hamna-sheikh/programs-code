#include<iostream>
using namespace std;
int main()
{
int n=5;
 int x=t1,y,t;
 
for(int i=1;i<=n;i--)
{
y=1;
t=x;
for (int s=n-1;s<=i;s++)
{
cout<<setw(3)<<"";
}
for(int j=;j>=i;j--)
}
{cout<<setw(3)<<t;
t=t-y;
y++;
}
x=x+i;
cout<<endl;
}
 return 0;
}
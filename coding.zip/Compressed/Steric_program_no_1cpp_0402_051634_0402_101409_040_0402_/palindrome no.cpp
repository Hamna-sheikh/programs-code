#include <iostream>
using namespace std;

int main() {
    int num, rev = 0, temp;
    cout << "Enter a number: ";
    cin >> num;
    temp = num;

    while (temp != 0) {
        rev = rev * 10 + temp % 10;
        temp /= 10;
    }

    if (rev == num)
        cout << num << " is a palindrome." << endl;
    else
        cout << num << " is not a palindrome." << endl;

    return 0;
}
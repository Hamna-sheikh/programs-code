//Write a program of upper paramid of no 1to 9? 




#include<iostream>
using namespace std;

int main()
{
int n=9;

for (int i=0;i<=9 ;i++)
{
for(int j=0;j<=i;j++)
{
   
  
  cout<<"i";
   }
   cout<<endl;
    }
   return 0; 
}

---

2// Find the Longest Consecutive Sequence in an Unsorted Array

#include <iostream>
#include <unordered_set>
using namespace std;

int findLongestConseqSubseq(int arr[], int n) {
    unordered_set<int> S(arr, arr + n);
    int longestStreak = 0;

    for (int num : S) {
        if (S.find(num - 1) == S.end()) {
            int currentNum = num;
            int streak = 1;

            while (S.find(currentNum + 1) != S.end()) {
                currentNum++;
                streak++;
            }
            longestStreak = max(longestStreak, streak);
        }
    }
    return longestStreak;
}

int main() {
    int arr[] = {1, 9, 3, 10, 4, 20, 2};
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Length of Longest Consecutive Sequence: " 
         << findLongestConseqSubseq(arr, n) << endl;
    return 0;}
    
#include <iostream>
using namespace std;

int main() {
    int n = 4, i = 1;
    do {
        int j = 1;
        do {
            cout << "* ";
            j++;
        } while (j <= n);
        cout << endl;
        i++;
    } while (i <= n);
    return 0;
}
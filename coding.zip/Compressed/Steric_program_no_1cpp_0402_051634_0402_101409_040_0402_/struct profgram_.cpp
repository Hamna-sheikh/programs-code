#include <iostream>
using namespace std;

struct Student {
    int id;
    string name;
    float marks;
};

int main() {
    const int SIZE = 2;
    Student students[SIZE];

    // Input student details
    for (int i = 0; i < SIZE; i++) {
        cout << "Enter details for student " << i + 1 << ":\n";
        cout << "ID: ";
        cin >> students[i].id;
        cin.ignore();  // Ignore leftover newline
        cout << "Name: ";
        getline(cin, students[i].name);
        cout << "Marks: ";
        cin >> students[i].marks;
    }

    // Display student details
    cout << "\nStudent Details:\n";
    for (int i = 0; i < SIZE; i++) {
        cout << "ID: " << students[i].id 
             << ", Name: " << students[i].name 
             << ", Marks: " << students[i].marks << "\n";
    }

    return 0;
}
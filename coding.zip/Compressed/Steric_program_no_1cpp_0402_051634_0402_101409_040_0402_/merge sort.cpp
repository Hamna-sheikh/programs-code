


---

1// Merge Two Sorted Arrays Without Extra Space

#include <iostream>
#include <algorithm>
using namespace std;

void mergeArrays(int arr1[], int arr2[], int n1, int n2) {
    for (int i = n2 - 1; i >= 0; i--) {
        int j, last = arr1[n1 - 1];
        for (j = n1 - 2; j >= 0 && arr1[j] > arr2[i]; j--)
            arr1[j + 1] = arr1[j];

        if (j != n1 - 2 || last > arr2[i]) {
            arr1[j + 1] = arr2[i];
            arr2[i] = last;
        }
    }
}urn 0;

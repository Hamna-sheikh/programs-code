//916
//253649
//648110012
//
//         PROGRAM NO 55
//
//
//



#include<iostream>
using namespace std;

int main()
{
int n=4;
int x=2;
for (int i=1;i<=n;i++)
{
for(int j=1;j<=i;j++)
{
   
  
  cout<<x*x<<"";
  x++;
   }
   cout<<endl;
    }
   return 0; 
}
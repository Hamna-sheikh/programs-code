#include <iostream>
using namespace std;

struct Pyramid {
    int rows;
};

void printPyramid(Pyramid p) {
    for (int i = 1; i <= p.rows; i++) {
        for (int j = 1; j <= p.rows - i; j++) {
            cout << " ";
        }
        for (int k = 1; k <= 2 * i - 1; k++) {
            cout << "*";
        }
        cout << endl;
    }
}

int main() {
    Pyramid p;
    cout << "Enter the number of rows for the pyramid: ";
    cin >> p.rows;

    printPyramid(p);

    return 0;
}
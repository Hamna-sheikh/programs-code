//Write a program of lower paramid of j? 




#include<iostream>
using namespace std;

int main()
{
int i=1,j=5;
for (int i=1;i<=5;i++)
{
for(int j=5;j>=i;j--)
{
   
  
  cout<<"j";
   }
   cout<<endl;
    }
   return 0; 
}
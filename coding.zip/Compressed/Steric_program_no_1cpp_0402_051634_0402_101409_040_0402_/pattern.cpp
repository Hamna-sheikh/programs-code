//Hollow saqre pattern
#include <iostream>
using namespace std;

int main() {
    int n = 4, i = 1;
    do {
        int j = 1;
        do {
            if (i == 1 || i == n || j == 1 || j == n) 
                cout << "* ";
            else 
                cout << "  ";
            j++;
        } while (j <= n);
        cout << endl;
        i++;
    } while (i <= n);
    return 0;
}
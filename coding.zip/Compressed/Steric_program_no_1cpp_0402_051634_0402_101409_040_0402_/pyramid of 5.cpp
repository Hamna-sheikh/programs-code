//Write a program of lower paramid of no 1to 5? 




#include<iostream>
using namespace std;

int main()
{
int n=5;
for (int i=1;i<=n ;i++)
{
for(int j=1;j<=n-i+1;j++)
{
   
  
  cout<<(n-i+j)<<"";
   }
   cout<<endl;
    }
   return 0; 
}